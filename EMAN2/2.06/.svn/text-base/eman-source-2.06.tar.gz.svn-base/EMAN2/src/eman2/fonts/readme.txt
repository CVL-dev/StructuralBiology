The fonts file DejaVuSerif.ttf was copied from a Fedore Core 9 installation. Specifically it was taken from  /usr/share/fonts/dejavu/DejaVuSerif.ttf.
David Woolford, August 12th 2008.
